"""Soukromá instance a nastavení aplikace v datové složce.

Soukromá instance (`NOKTURNO_SOUKROMA=1`, v `nokturno.json` `"soukroma": true`) může mít
adresu doplňku v internetu, ale obslouží jen nastavení, která majitel povolil. Povolená
jsou v `povolena.txt` v datové složce, jeden otisk (`otisk()`) na řádek, `#` je komentář.
Soubor se čte znovu, když se změní, takže ruční úprava platí bez restartu.

Otisk se počítá bez tokenu identity (`id`): ten si formulář dotahuje na pozadí a adresa
by se jím po povolení změnila.

Požadavek, který přišel přes Cloudflare (hlavička `Cf-Connecting-IP`), je „z proxy":
na soukromé instanci smí jen na cesty doplňku, formulář ani `/povolit` nedostane.
Hlavní ochrana je v nginx, tohle je druhá pojistka.

`aplikace.json` drží volby aplikace, které jde změnit na `/configure` (statistiky,
hlášení o pádech, profily a heslo k nastavení) — na Androidu `nokturno.json` upravit
nejde. Má přednost před prostředím. Heslo je v něm jen jako hash (`hash_hesla`).
"""
import hashlib
import hmac
import json
import os
import re
import tempfile
import threading
import urllib.parse

from . import config

POVOLENA = "povolena.txt"
APLIKACE = "aplikace.json"
OTISK_RE = re.compile(r"^[0-9a-f]{16}$")


def z_proxy(headers):
    """Požadavek z internetu přes Cloudflare. Výjimka: admin.* za Cloudflare Access s přihlášeným
    uživatelem (Access hlavičku doplní až po ověření; cesty k tomuhle hostu jinak nevedou)."""
    if not headers.get("Cf-Connecting-IP"):
        return False
    admin = str(headers.get("Host") or "").lower().startswith("admin.")
    return not (admin and headers.get("Cf-Access-Authenticated-User-Email"))


def otisk(options):
    return config.fingerprint({k: v for k, v in (options or {}).items() if k != config.ID_KLIC})


def otisk_z_textu(text):
    """Adresa doplňku, samotný kousek `/c/<nastavení>` nebo rovnou otisk → otisk; None = nečitelné."""
    text = urllib.parse.unquote((text or "").strip())
    if OTISK_RE.match(text):
        return text
    m = re.search(r"/c/([^/?#]+)", text)
    options = config.decode(m.group(1) if m else text)
    return otisk(options) if options else None


class Povolena:
    def __init__(self, data_dir):
        self.cesta = os.path.join(data_dir, POVOLENA)
        self._zamek = threading.Lock()
        self._mtime = None
        self._otisky = frozenset()

    def _nacti(self):
        try:
            mtime = os.stat(self.cesta).st_mtime_ns
        except OSError:
            mtime = None
        if mtime != self._mtime:
            try:
                with open(self.cesta, encoding="utf-8") as f:
                    radky = [r.split("#")[0].strip() for r in f]
            except OSError:
                radky = []
            self._otisky = frozenset(r for r in radky if r)
            self._mtime = mtime
        return self._otisky

    def obsahuje(self, o):
        with self._zamek:
            return o in self._nacti()

    def pridej(self, o):
        """True = nově připsán."""
        with self._zamek:
            if o in self._nacti():
                return False
            os.makedirs(os.path.dirname(self.cesta) or ".", exist_ok=True)
            with open(self.cesta, "a", encoding="utf-8") as f:
                f.write(o + "\n")
            return True


def nacti_aplikaci(data_dir):
    try:
        with open(os.path.join(data_dir, APLIKACE), encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


_APLIKACE_ZAMEK = threading.Lock()   # přečíst–změnit–zapsat najednou: souběžné uložení by změnu ztratilo


def zapis_json(cesta, data):
    """Atomický zápis s právy 0600 přes vlastní dočasný soubor (souběžné zápisy si ho nepřepíšou)."""
    os.makedirs(os.path.dirname(cesta) or ".", exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=os.path.basename(cesta) + ".", dir=os.path.dirname(cesta) or ".")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:   # mkstemp zakládá rovnou s právy 0600
            json.dump(data, f)
        os.replace(tmp, cesta)
    except BaseException:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise


def uloz_aplikaci(data_dir, zmeny, smazat=()):
    with _APLIKACE_ZAMEK:
        data = {k: v for k, v in {**nacti_aplikaci(data_dir), **zmeny}.items() if k not in smazat}
        zapis_json(os.path.join(data_dir, APLIKACE), data)   # nese hash hesla správce
    return data


def hash_hesla(heslo):
    """Heslo k nastavení do `aplikace.json`: `pbkdf2$<sůl>$<hash>`."""
    sul = os.urandom(16).hex()
    return "pbkdf2$" + sul + "$" + hashlib.pbkdf2_hmac("sha256", heslo.encode("utf-8"), bytes.fromhex(sul), 200_000).hex()


def heslo_odpovida(zadane, ulozene):
    """`ulozene` je hash z `hash_hesla`, nebo holé heslo z `NOKTURNO_HESLO`."""
    if ulozene.startswith("pbkdf2$"):
        _, sul, hodnota = ulozene.split("$", 2)
        try:
            vypocet = hashlib.pbkdf2_hmac("sha256", zadane.encode("utf-8"), bytes.fromhex(sul), 200_000).hex()
        except ValueError:
            return False
        return hmac.compare_digest(vypocet, hodnota)
    return hmac.compare_digest(zadane.encode("utf-8"), ulozene.encode("utf-8"))
