"""HTTP vrstva doplňku.

Stojí na `http.server` ze standardní knihovny, protože jádro je taky bez
závislostí a volání v něm jsou blokující. `ThreadingHTTPServer` obslouží každý
požadavek ve vlákně, takže dlouhé hledání na WebShare nezastaví ostatní dotazy —
stejný vzor, jakým dnes integrace pro Home Assistant pouští jádro v executoru.

    python3 -m nokturno.server --port 7127
"""
import argparse
import base64
import logging
import mimetypes
import os
import re
import shutil
import ssl
import sys
import threading
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from .config import decode, fingerprint, from_environ, sources_summary
from .katalogy import Katalogy
from .core.lib import keepalive, smbfs
from .core.lib.dash_api import DashApi
from .core.lib.tmdb_api import TmdbApi
from .identita import Identita
from .enginy import Enginy
from .routes import Blokace, VERZE, Odpoved, Router, jazyk_z_hlavicky, klient_z_useragent
from .statistiky import Statistiky
from .overovani import Overovani
from .pady import Pady
from .provoz import Provoz
from . import cztor, kliky as kliky_zprav, sit, soukroma, tls
from . import spravce as spravce_mod
from .uzivatele import Uzivatele

_LOGGER = logging.getLogger("nokturno")
# Novější Python hlásí .mkv jako video/matroska, přehrávače znají video/x-matroska.
mimetypes.add_type("video/x-matroska", ".mkv")

VYCHOZI_PORT = 7127          # hned vedle Luny na 7126
VYCHOZI_DATA = "./data"      # cache a mezipaměť jádra; v kontejneru svazek

# Strop souběžných spojení. `ThreadingHTTPServer` sám žádný nemá — na každé
# otevřené spojení založí vlákno a drží ho, dokud klient nezavře nebo nevyprší
# `Handler.timeout`. Kdo pošle hlavičku po bajtu (slowloris), obsadí tím tolik
# vláken, kolik jich stihne otevřít.
#
# Uživatelů může být kolik chce — doplněk poslouchá jen na 127.0.0.1 za Tailscale
# Funnelem a `tailscaled` spojení na backend sdružuje, takže jich je zhruba tolik,
# kolik je zrovna rozpracovaných požadavků (měřeno 2026-09-20: 30 souběžných
# požadavků zvenku = 2 až 3 spojení sem). Naměřená špička souběžnosti za běžný den
# je 54, za útočnou noc 18. → 19. 9. to bylo 146. Odtud 400: čtyřnásobek běžné
# špičky a s rezervou nad útok. Nečinné vlákno stojí jen svůj zásobník, ne procesor.
MAX_SPOJENI = int(os.environ.get("NOKTURNO_MAX_SPOJENI", "400"))


# Diagnostika „doplněk po čase nic nenajde, v logu ticho" (Discord, 2026-11-02): bez `--debug`
# se dřív nedalo poznat, jestli dotaz vůbec dorazil, visí v jádře, nebo ho odmítl limit.
_SLEDOVANE_RE = re.compile(r"^(?:/c/[^/]+)?/(?:stream|catalog|meta)/")
ZASEKNUTY_S = 60             # obsluha delší než tohle → WARNING se zásobníkem vlákna
_BEZICI = {}                 # id vlákna → [začátek, cesta, nahlášeno]
_BEZICI_ZAMEK = threading.Lock()
_ODMITNUTI = {"posledni": 0.0, "pocet": 0}


def _hlidac_zaseknutych(interval_s=15):
    """Na pozadí: dotaz na streamy/katalog/meta, který běží přes `ZASEKNUTY_S`, se jednou ohlásí
    i se zásobníkem, ať je vidět, kde visí (zámek, fond vláken, síť bez timeoutu)."""
    while True:
        time.sleep(interval_s)
        try:
            _zkontroluj_zaseknute()
        except Exception:  # noqa: BLE001 – diagnostika nesmí skončit
            _LOGGER.debug("hlídač zaseknutých dotazů selhal", exc_info=True)


def _zkontroluj_zaseknute():
    """Jedno kolo hlídače; vrací počet nově ohlášených dotazů."""
    ted = time.monotonic()
    with _BEZICI_ZAMEK:
        dlouhe = [(tid, z) for tid, z in _BEZICI.items() if not z[2] and ted - z[0] > ZASEKNUTY_S]
        for _, z in dlouhe:
            z[2] = True
    if not dlouhe:
        return 0
    ramce = sys._current_frames()   # noqa: SLF001 – jediný způsob, jak získat zásobník cizího vlákna
    for tid, (zacatek, cesta, _) in dlouhe:
        zasobnik = "".join(traceback.format_stack(ramce[tid])) if tid in ramce else "(vlákno už skončilo)\n"
        _LOGGER.warning("dotaz běží %d s: %s\n%s", ted - zacatek, cesta, zasobnik.rstrip())
    return len(dlouhe)


def _hlas_odmitnuti(duvod, cesta):
    """Odmítnutí limitem nebo blokací do logu — nejvýš jednou za minutu, zbytek jako počet."""
    ted = time.monotonic()
    _ODMITNUTI["pocet"] += 1
    if ted - _ODMITNUTI["posledni"] < 60:
        return
    _LOGGER.warning("odmítnuto (%s): %s, za poslední minutu odmítnutí celkem %d",
                    duvod, cesta, _ODMITNUTI["pocet"])
    _ODMITNUTI["posledni"], _ODMITNUTI["pocet"] = ted, 0


# Hlídač posluchačů (Discord, „doplněk po čase nic nenajde", 2026-11-14): na 12.4.4 nedorazil
# do obsluhy ani jeden dotaz (chyběl i řádek „dotaz …"), proces přitom žil, takže zavaděč,
# který hlídá jen konec procesu, nic nepoznal a pomohl až ruční restart. Hlídač se každou
# minutu zeptá vlastních posluchačů na /health; po `HLIDAC_SELHANI` neúspěších za sebou
# zapíše zásobníky všech vláken do logu i do hlášení o pádu a pod zavaděčem proces ukončí,
# zavaděč ho spustí znovu.
HLIDAC_S = 60
HLIDAC_SELHANI = 3
HLIDAC_TIMEOUT_S = 10


def _zkus_posluchac(host, port, https=False, timeout=HLIDAC_TIMEOUT_S):
    """True, když posluchač odpoví na /health stavem 200."""
    import http.client   # noqa: PLC0415 – jen pro hlídač
    if host in ("", "0.0.0.0"):
        host = "127.0.0.1"
    elif host == "::":
        host = "::1"
    if https:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False           # certifikát local-ip.co na 127.0.0.1 nesedí, jde o odezvu
        ctx.verify_mode = ssl.CERT_NONE
        spojeni = http.client.HTTPSConnection(host, port, timeout=timeout, context=ctx)
    else:
        spojeni = http.client.HTTPConnection(host, port, timeout=timeout)
    try:
        spojeni.request("GET", "/health", headers={"Connection": "close", "User-Agent": "nokturno-hlidac"})
        return spojeni.getresponse().status == 200
    except (OSError, http.client.HTTPException):
        return False
    finally:
        spojeni.close()


def _zasobniky_vlaken(ramcu=8):
    """Řádek na vlákno: jméno a posledních pár rámců (soubor:funkce:řádek) – vejde se do hlášení o pádu."""
    jmena = {t.ident: t.name for t in threading.enumerate()}
    radky = []
    for tid, ramec in sys._current_frames().items():   # noqa: SLF001 – zásobník cizího vlákna jinak nejde
        cesta = " > ".join(f"{os.path.basename(r.filename)}:{r.name}:{r.lineno}"
                           for r in traceback.extract_stack(ramec)[-ramcu:])
        radky.append(f"{jmena.get(tid, tid)}: {cesta}")
    return radky


class HlidacPosluchacu:
    """`posluchace` = [(jméno, host, port, https)]. `ukoncit` jen pod zavaděčem, který proces znovu spustí."""

    def __init__(self, posluchace, pady=None, ukoncit=False, selhani=HLIDAC_SELHANI, timeout_s=HLIDAC_TIMEOUT_S):
        self.posluchace = list(posluchace)
        self.pady = pady
        self.ukoncit = ukoncit
        self.selhani = selhani
        self.timeout_s = timeout_s
        self.spatne = 0

    def kolo(self):
        """Jedno kolo; True = posluchače neodpověděly `selhani`× za sebou (už nahlášeno)."""
        vadne = [jmeno for jmeno, host, port, https in self.posluchace
                 if not _zkus_posluchac(host, port, https, self.timeout_s)]
        if not vadne:
            if self.spatne:
                _LOGGER.info("posluchače zase odpovídají")
            self.spatne = 0
            return False
        self.spatne += 1
        _LOGGER.warning("posluchač neodpovídá na /health: %s (%d/%d)", ", ".join(vadne), self.spatne, self.selhani)
        if self.spatne < self.selhani:
            return False
        self.spatne = 0
        _LOGGER.error("doplněk %d× za sebou neodpověděl (%s), zásobníky vláken:", self.selhani, ", ".join(vadne))
        for radek in _zasobniky_vlaken():
            _LOGGER.error("  %s", radek)
        if self.pady is not None:
            try:
                raise RuntimeError(f"posluchač neodpovídá: {', '.join(vadne)}")
            except RuntimeError as chyba:
                self.pady.zaznamenej(chyba, "/health")
        return True

    def bez(self, interval_s=HLIDAC_S):
        while True:
            time.sleep(interval_s)
            try:
                if self.kolo() and self.ukoncit:
                    time.sleep(3)   # ať hlášení stihne odejít; nestihne-li, pošle ho start (`pady.odesli`)
                    _LOGGER.error("ukončuji doplněk, zavaděč ho spustí znovu")
                    for h in logging.getLogger().handlers:
                        h.flush()
                    os._exit(3)
            except Exception:  # noqa: BLE001 – hlídač nesmí skončit
                _LOGGER.debug("hlídač posluchačů selhal", exc_info=True)


_CORS_RE = re.compile(r"^(?:/c/[^/]+)?/(?:manifest\.json|health|stream/.+\.json|catalog/.+\.json|meta/.+\.json|play/.+)$")


def cors_povoleno(path):
    """Jen cesty protokolu Stremia (manifest, streamy, katalog, přehrání, health) dostanou
    `Access-Control-Allow-Origin: *`. Formulář, `/check` a `/identita*` ne."""
    return bool(_CORS_RE.match((path or "").partition("?")[0]))


# Od 9.0.0 běží doplněk jen u uživatele (aplikace se zavaděčem), žádná veřejná instance.
# Všechno je tedy „domácí": úložiště v LAN, účty z prostředí. Kdo by službu vystavil
# do internetu za proxy, zapne starou ochranu `NOKTURNO_VEREJNA=1`.
VEREJNA_INSTANCE = os.environ.get("NOKTURNO_VEREJNA", "").strip().lower() in ("1", "true", "ano", "yes")


def je_verejny(headers, client_ip):
    """Přišel požadavek z internetu přes Tailscale Funnel? (jen s `NOKTURNO_VEREJNA=1`)

    Veřejný požadavek nesmí dostat výchozí nastavení z prostředí — tedy účty
    WebShare a Streamuj majitele instance. Rozhoduje se tak, aby pochybnost
    znamenala „veřejný":

    - `Tailscale-Funnel-Request` přidává Funnel ke každému požadavku z internetu;
    - `Tailscale-User-Login` přidává `tailscale serve` jen přihlášenému uživateli
      tailnetu. Funnel tyhle hlavičky od klienta zahodí, podvrhnout nejdou
      (ověřeno 2026-09-13 zvenku s ručně poslanou hlavičkou);
    - přímý přístup mimo proxy Tailscale (LAN na :7127) je soukromý jako dřív,
      ale bez identity přes proxy (tagované zařízení, cokoli nečekaného) už ne.
    """
    if not VEREJNA_INSTANCE:
        return False
    if headers.get("Tailscale-Funnel-Request"):
        return True
    if headers.get("Tailscale-User-Login"):
        return False
    return client_ip in ("127.0.0.1", "::1", "::ffff:127.0.0.1")


def bezpecna_cesta(path):
    """Cesta do logu: `/c/<účty>/…` → `/c/<otisk>/…`. Adresa doplňku je fakticky heslo
    (viz CLAUDE.md), do journalu nepatří ani při chybě."""
    def otisk(m):
        options = decode(m.group(1))
        return "/c/" + (fingerprint(options) if options else "?")
    return re.sub(r"^/c/([^/?]+)", otisk, path or "")


def dash_lokalne(provoz, cache, tmdb=None):
    """Katalogy z dashboardu a `/discover`. Doplněk běží na témže stroji jako dashboard,
    takže se ptá přímo (mimo nginx a tunel) a prokáže se tokenem z `/traffic`.
    Bez tokenu (vlastní instance) jde na veřejnou adresu."""
    if not provoz.token or not provoz.url.endswith("/traffic"):
        return DashApi(cache=cache, tmdb=tmdb)
    return DashApi(cache=cache, base=provoz.url[:-len("/traffic")], headers={"X-Nokturno-Token": provoz.token},
                   tmdb=tmdb)


def uklid_dat(data_dir, max_age_s=30 * 86400):
    """Složky jader, na které se 30 dní nesáhlo — každá adresa doplňku má vlastní,
    a ty s překlepem nebo od zkoušejících by jinak zůstaly navždy."""
    hranice = time.time() - max_age_s
    smazano = 0
    try:
        for name in os.listdir(data_dir):
            path = os.path.join(data_dir, name)
            if os.path.isdir(path) and re.fullmatch(r"[0-9a-f]{16}", name) and os.path.getmtime(path) < hranice:
                shutil.rmtree(path, ignore_errors=True)
                smazano += 1
    except OSError:
        pass
    return smazano


def uklid_cache(data_dir, max_age_s=72 * 3600):
    """Prošlé soubory `cache/*.json` uvnitř složek jader (`Store.cached_if()`, TTL
    se hlídá jen při čtení). Kodi i HA tohle spouští svou vlastní údržbou
    (`Store.prune_cache()`), Stremio žádnou periodickou údržbu nemělo — jedna
    adresa doplňku se stránkovacím parametrem `skip` (katalogy.py) tak nasbírala
    přes 400 000 souborů za pár dní a došly inody celému kontejneru i sousednímu
    dashboardu (incident 2026-09-19). Volá `_udrzba_smycka` jednou za hodinu."""
    hranice = time.time() - max_age_s
    smazano = 0
    try:
        for name in os.listdir(data_dir):
            cdir = os.path.join(data_dir, name, "cache")
            if not os.path.isdir(cdir):
                continue
            for fn in os.listdir(cdir):
                fp = os.path.join(cdir, fn)
                try:
                    if os.path.getmtime(fp) < hranice:
                        os.remove(fp)
                        smazano += 1
                except OSError:
                    pass
    except OSError:
        pass
    return smazano


def _udrzba_smycka(data_dir, interval_s=3600):
    """Na pozadí, ať i dlouho běžící proces (žádný restart = žádné spuštění
    `uklid_dat` ze `vytvor_server`) nenechá cache prošlých požadavků růst navždy."""
    while True:
        time.sleep(interval_s)
        try:
            smazano = uklid_cache(data_dir)
            if smazano:
                _LOGGER.info("úklid cache: %d prošlých souborů", smazano)
        except Exception:
            _LOGGER.exception("úklid cache selhal")


def _uklada_vyuziti(vyuziti, interval_s=300):
    """Využití profilů (profily.Vyuziti) drží paměť, na disk jde jednou za 5 minut."""
    while True:
        time.sleep(interval_s)
        try:
            vyuziti.uloz()
        except Exception:  # noqa: BLE001 – plný disk ani práva nesmí zastavit smyčku
            _LOGGER.exception("uložení využití profilů selhalo")


def potrebuje_heslo(cesta, router):
    """Formulář, profily a správa chtějí heslo (`NOKTURNO_HESLO`); úvodní stránka a cesty doplňku nikdy."""
    if not getattr(router, "heslo", ""):   # getattr: zkušební směrovače v testech heslo nemají
        return False
    return bool(router._formular(cesta) or cesta in Router.PROFILY_CESTY or cesta in Router.SPRAVA
                or cesta == Router.OVERENI or cesta.startswith(("/spravce/", "/ucet/")))


def heslo_sedi(hlavicka, heslo):
    """`Authorization: Basic base64("<cokoli>:<heslo>")`; jméno se nekontroluje. `heslo` je hash
    z `aplikace.json`, nebo holé heslo z `NOKTURNO_HESLO`."""
    try:
        typ, _, data = (hlavicka or "").partition(" ")
        if typ.lower() != "basic":
            return False
        zadane = base64.b64decode(data.strip(), validate=True).decode("utf-8").partition(":")[2]
    except (ValueError, UnicodeDecodeError):
        return False
    return soukroma.heslo_odpovida(zadane, heslo)


class Handler(BaseHTTPRequestHandler):
    server_version = f"nokturno/{VERZE}"
    sys_version = ""                 # verze Pythonu do hlavičky Server nepatří
    protocol_version = "HTTP/1.1"    # Stremio drží spojení otevřené
    # Nečinné spojení nesmí držet vlákno navždy. Je to socket timeout, takže platí
    # i na čekání na další požadavek v keep-alive a na zápis odpovědi. Audit chtěl
    # 15 s; 30 s je kompromis — odpovědi katalogů mají stovky kilobajtů a pomalé
    # mobilní spojení by na patnácti vteřinách utnulo zápis. Proti slowlorisu drží
    # `MAX_SPOJENI`, ne tohle.
    timeout = 30
    _verejny = True                  # do_GET přepíše; při pochybnosti veřejný
    # měření provozu; instance handleru žije přes celé keep-alive spojení, takže
    # `_zacni()` je na začátku každé obsluhy, ne v konstruktoru
    _zacatek = 0.0
    _stav = 0
    _zapsano = 0
    _nahlaseno = True

    # hlavičky pro stránky (úvod, formulář): žádné cizí skripty, žádné vkládání do
    # rámu, žádný Referer — formulář sbírá hesla a jeho adresa nese účty
    HLAVICKY_STRANEK = (
        ("Content-Security-Policy", "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; "
                                    "img-src https://raw.githubusercontent.com data:; connect-src 'self' https://api.github.com; worker-src blob:; "
                                    "base-uri 'none'; frame-ancestors 'none'"),
        ("X-Content-Type-Options", "nosniff"),
        ("X-Frame-Options", "DENY"),
        ("Referrer-Policy", "no-referrer"),
        # Funnel HSTS nepřidává; stránka sbírá hesla, ať prohlížeč na http už nechodí
        ("Strict-Transport-Security", "max-age=31536000"),
    )

    def _hlavicky_stranek(self):
        """`HLAVICKY_STRANEK`; vlastní instance s HTTPS v síti navíc smí z formuláře ověřit svou
        adresu přes local-ip.co (kontrola DNS rebinding v `configure.html`) — jen na port HTTPS."""
        port = getattr(getattr(self.server, "router", None), "https_port", 0)
        if not port:
            return self.HLAVICKY_STRANEK
        zdroj = f"connect-src 'self' https://api.github.com https://*.{tls.DOMENA}:{port};"
        return tuple((j, h.replace("connect-src 'self' https://api.github.com;", zdroj)) if j == "Content-Security-Policy" else (j, h)
                     for j, h in self.HLAVICKY_STRANEK)

    # --- měření provozu (provoz.py) ---------------------------------------
    def _zacni(self):
        self._zacatek = time.monotonic()
        self._stav = 0
        self._zapsano = 0
        self._utok = None
        self._nahlaseno = False

    def send_response(self, code, message=None):
        self._stav = code
        super().send_response(code, message)

    def _nahlas(self):
        """Jeden řádek do fronty provozu. Volá se z každé obsluhy v `finally`, ať
        se dostane i na spojení, které klient uprostřed zavřel."""
        provoz = getattr(self.server, "provoz", None)
        if provoz is None or getattr(self, "_nahlaseno", True):
            return
        self._nahlaseno = True
        try:
            if self._utok:
                # blokované a přetížené nastavení: ne do provozu, jen do přehledu útočníků
                provoz.zaznamenej_utok(self._klient(), self.headers.get("User-Agent"), *self._utok[::-1],
                                       ma_id=self.server.router.ma_identitu(self.path), cesta=self.path)
                return
            provoz.zaznamenej(self.path, self.command or "GET", self._stav or 499, self._zapsano,
                              int((time.monotonic() - self._zacatek) * 1000),
                              klient_z_useragent(self.headers.get("User-Agent")))
        except Exception:  # noqa: BLE001 – statistika provozu nesmí nic shodit
            _LOGGER.debug("provoz se nezaznamenal", exc_info=True)

    # --- pomůcky ----------------------------------------------------------
    def _klient(self):
        """Adresa klienta — přes Tailscale proxy z X-Forwarded-For, jinak peer."""
        peer = self.client_address[0]
        if peer in ("127.0.0.1", "::1", "::ffff:127.0.0.1"):
            xff = self.headers.get("X-Forwarded-For", "")
            if xff:
                return xff.split(",")[0].strip()
        return peer

    def _zaklad(self):
        """Absolutní adresa, na kterou se klient ptá.

        Bere se z hlavičky požadavku, ne z nastavení: Stremio přehrává na jiném
        zařízení, než kde běží služba, a odkazy na `/play/` mu musí zůstat
        dosažitelné. Hlavičky X-Forwarded-* respektujeme kvůli případné proxy.
        """
        host = self.headers.get("X-Forwarded-Host") or self.headers.get("Host")
        if not host:
            host = f"{self.server.server_address[0]}:{self.server.server_address[1]}"
        schema = self.headers.get("X-Forwarded-Proto") or getattr(self.server, "schema", "http")
        return f"{schema}://{host}"

    def _cors(self):
        """CORS jen na cesty protokolu Stremia (webový klient je tahá z jiného originu).
        Formulář, `/check` a `/identita*` ho nepotřebují — a s `*` by cizí web mohl
        v prohlížečích návštěvníků těžit identity z tisíců adres (audit 2026-09-19)."""
        if cors_povoleno(self.path):
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Headers", "*")

    def _proxy(self, url, hlavicky):
        """Soubor z vlastního úložiště nebo FastShare přes aplikaci – s hlavičkou, kterou přehrávač nemá.

        Přeposílá `Range`, takže přetáčení funguje a nic se nestahuje celé dopředu.
        Heslo ani adresa úložiště klientovi neodejdou, dostane jen data.
        Soubor ze SMB (`SmbFile`, HTTP adresu nemá) pošle `_proxy_smb`.
        """
        if hasattr(url, "chunks"):
            self._proxy_smb(url)
            return
        pozadavek = dict(hlavicky)
        for jmeno in ("Range", "If-Range"):
            if self.headers.get(jmeno):
                pozadavek[jmeno] = self.headers[jmeno]
        # bez komprese: tělo se přeposílá po kouscích tak, jak přijde
        pozadavek.setdefault("Accept-Encoding", "identity")
        req = urllib.request.Request(url, headers=pozadavek, method="HEAD" if self.command == "HEAD" else "GET")
        # z internetu jen hlídaným openerem: úložiště může přesměrovat dovnitř sítě
        otevri = sit.OPENER.open if getattr(self, "_verejny", True) else urllib.request.urlopen
        try:
            upstream = otevri(req, timeout=30)
        except urllib.error.HTTPError as err:
            upstream = err     # 416 a spol. patří klientovi, jen 401/403 se přeloží
        except Exception as err:  # noqa: BLE001 – síť, DNS, zakázaná adresa
            _LOGGER.info("úložiště neodpovídá: %s", err)
            self._posli(Odpoved(status=502, text="Úložiště neodpovídá."))
            return
        with upstream:
            status = getattr(upstream, "status", None) or upstream.code
            if status in (401, 403):
                self._posli(Odpoved(status=502, text="Úložiště odmítlo jméno nebo heslo."))
                return
            self.send_response(status)
            self._odeslano = True   # chyba odteď nesmí poslat druhou odpověď do téhož spojení
            for jmeno in ("Content-Type", "Content-Length", "Content-Range", "Accept-Ranges",
                          "Last-Modified", "ETag"):
                if upstream.headers.get(jmeno):
                    self.send_header(jmeno, upstream.headers[jmeno])
            if not upstream.headers.get("Content-Length"):
                self.close_connection = True   # bez délky jde konec poznat jen zavřením
            self._cors()
            self.end_headers()
            if self.command == "HEAD":
                return
            while True:
                try:
                    kus = upstream.read(256 * 1024)
                except OSError as err:
                    # úložiště uprostřed souboru přestalo posílat – přehrávač se připojí znovu s Range
                    _LOGGER.info("úložiště přestalo posílat data: %s", err)
                    self.close_connection = True
                    return
                if not kus:
                    break
                try:
                    self.wfile.write(kus)
                    self._zapsano += len(kus)
                except TimeoutError:
                    # přehrávač přestal číst déle než `timeout` (pauza, plný buffer) – jako zavřené spojení
                    self.close_connection = True
                    return

    def _proxy_smb(self, soubor):
        """Soubor z vlastního úložiště na SMB po kusech (`SmbFile.chunks`) s `Range`, ať jde přetáčet."""
        try:
            velikost = soubor.size()
        except Exception as err:  # noqa: BLE001 – síť, SMB, přihlášení
            _LOGGER.info("úložiště neodpovídá: %s", err)
            self._posli(Odpoved(status=502, text="Úložiště neodpovídá."))
            return
        try:
            rozsah = smbfs.parse_range(self.headers.get("Range"), velikost)
        except ValueError:
            self.send_response(416)
            self._odeslano = True
            self.send_header("Content-Range", f"bytes */{velikost}")
            self.send_header("Content-Length", "0")
            self._cors()
            self.end_headers()
            return
        start, konec = rozsah or (0, velikost - 1)
        self.send_response(206 if rozsah else 200)
        self._odeslano = True
        self.send_header("Content-Type", mimetypes.guess_type(soubor.name)[0] or "application/octet-stream")
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(max(0, konec - start + 1)))
        if rozsah:
            self.send_header("Content-Range", f"bytes {start}-{konec}/{velikost}")
        self._cors()
        self.end_headers()
        if self.command == "HEAD":
            return
        try:
            for kus in soubor.chunks(start, konec):
                self.wfile.write(kus)
                self._zapsano += len(kus)
        except Exception as err:  # noqa: BLE001 – přehrávač zavřel spojení, SMB přestalo posílat
            _LOGGER.info("soubor ze SMB přerušen: %s", err)
            self.close_connection = True

    def _posli(self, odpoved):
        self._utok = getattr(odpoved, "utok", None)
        telo, typ = odpoved.body
        if self._utok:
            _hlas_odmitnuti(self._utok[0], bezpecna_cesta(self.path))
        self.send_response(odpoved.status)
        self._odeslano = True   # od teď už nejde poslat druhou odpověď (viz do_GET)
        if self._utok:
            # Odmítnutý požadavek (limit, blokace) nesmí držet keep-alive: odpověď
            # trvá milisekundu, ale spojení by po ní zůstalo viset `Handler.timeout`
            # sekund a držet vlákno. Kdo mlátí do limitu, obsadí tím jinak
            # `MAX_SPOJENI` i bez jediného vyřízeného požadavku.
            # `send_header("Connection", "close")` zároveň nastaví `close_connection`.
            self.send_header("Connection", "close")
        if odpoved.location:
            self.send_header("Location", odpoved.location)
        for jmeno, hodnota in getattr(odpoved, "hlavicky", ()):
            self.send_header(jmeno, hodnota)
        self.send_header("Content-Type", typ)
        self.send_header("Content-Length", str(len(telo)))
        self._cors()
        if odpoved.html is not None:
            self.send_header("Vary", "Accept-Language")   # stránky jsou česky nebo slovensky
            for jmeno, hodnota in self._hlavicky_stranek():
                self.send_header(jmeno, hodnota)
        if self.path.startswith("/c/"):
            # adresa nese účty — nic z ní nemá zůstat v cache prohlížeče ani proxy
            self.send_header("Cache-Control", "no-store")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(telo)
            self._zapsano += len(telo)

    def _vyzvi_k_heslu(self):
        """401 s výzvou k heslu; True = odpověď odešla a obsluha končí."""
        cesta = urllib.parse.urlsplit(self.path).path
        router = self.server.router
        if not potrebuje_heslo(cesta, router) or heslo_sedi(self.headers.get("Authorization"), router.heslo):
            return False
        self.send_response(401)
        self._odeslano = True
        self.send_header("WWW-Authenticate", 'Basic realm="Nokturno", charset="UTF-8"')
        self.send_header("Content-Length", "0")
        self.end_headers()
        return True

    # --- metody -----------------------------------------------------------
    def do_GET(self):
        self._odeslano = False
        self._zacni()
        sledovat = bool(_SLEDOVANE_RE.match(self.path or ""))
        if sledovat:
            cesta = bezpecna_cesta(self.path)
            _LOGGER.info("dotaz %s (%s)", cesta, klient_z_useragent(self.headers.get("User-Agent")) or "?")
            with _BEZICI_ZAMEK:
                _BEZICI[threading.get_ident()] = [time.monotonic(), cesta, False]
        try:
            if self._vyzvi_k_heslu():
                return
            verejny = je_verejny(self.headers, self.client_address[0])
            self._verejny = verejny
            jazyk = jazyk_z_hlavicky(self.headers.get("Accept-Language"))
            aplikace = klient_z_useragent(self.headers.get("User-Agent"))
            odpoved = self.server.router.route(self.path, self._zaklad(), verejny=verejny, jazyk=jazyk,
                                               klient=self._klient(), aplikace=aplikace,
                                               z_proxy=soukroma.z_proxy(self.headers), hlavicky=self.headers)
            if getattr(odpoved, "proxy", None):
                self._proxy(*odpoved.proxy)
            else:
                self._posli(odpoved)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, ssl.SSLError):
            # přehrávač si to rozmyslel a zavřel spojení — běžné, ne chyba
            _LOGGER.debug("klient zavřel spojení při %s", bezpecna_cesta(self.path))
        except Exception:  # noqa: BLE001 – žádná chyba nesmí ukončit službu
            _LOGGER.exception("neočekávaná chyba při %s", bezpecna_cesta(self.path))
            pady = getattr(self.server, "pady", None)
            if pady is not None:
                pady.zaznamenej(sys.exc_info()[1], self.path)
            if self._odeslano:
                self.close_connection = True   # hlavičky už odešly — druhá odpověď by rozbila keep-alive
                return
            try:
                # text stavového řádku musí být latin-1 — „Chyba doplňku" tam dřív shodilo
                # odeslání a klient čekal na timeout; česky jde jen do těla odpovědi
                self.send_error(500, "Internal Server Error", "Chyba doplňku")
            except Exception:  # noqa: BLE001 – klient už mohl spojení zavřít
                self.close_connection = True
        finally:
            if sledovat:
                with _BEZICI_ZAMEK:
                    _BEZICI.pop(threading.get_ident(), None)
            self._nahlas()

    def do_POST(self):
        """Jen `/povolit`, `/profil` a `/aplikace` z formuláře (viz `Router.post`)."""
        self._odeslano = False
        self._zacni()
        try:
            if self._vyzvi_k_heslu():
                return
            delka = int(self.headers.get("Content-Length") or 0)
            if not 0 <= delka <= 64 * 1024:
                self._posli(Odpoved(status=413, text=""))
                return
            telo = self.rfile.read(delka).decode("utf-8", "replace")
            self._posli(self.server.router.post(self.path, telo, self.headers, zaklad=self._zaklad(), klient=self._klient(),
                                                verejny=je_verejny(self.headers, self.client_address[0])))
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, ssl.SSLError):
            pass
        except Exception:  # noqa: BLE001 – žádná chyba nesmí ukončit službu
            _LOGGER.exception("neočekávaná chyba při POST %s", bezpecna_cesta(self.path))
            if not self._odeslano:
                self.send_error(500, "Internal Server Error")
        finally:
            self._nahlas()

    def do_HEAD(self):
        # HEAD na streamy/ověření dřív spustilo celé hledání ve zdrojích jen kvůli hlavičkám
        if "/stream/" in self.path or self.path.rstrip("/").endswith("/check"):
            self._zacni()
            try:
                self.send_response(204)
                self.send_header("Content-Length", "0")
                self._cors()
                self.end_headers()
            finally:
                self._nahlas()
            return
        self.do_GET()

    def do_OPTIONS(self):
        self._zacni()
        try:
            self.send_response(204)
            self._cors()
            if cors_povoleno(self.path):
                self.send_header("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS")
            self.send_header("Content-Length", "0")
            self.end_headers()
        finally:
            self._nahlas()

    def log_message(self, format, *args):  # noqa: A002 – podpis dává BaseHTTPRequestHandler
        _LOGGER.debug("%s %s", self.address_string(), bezpecna_cesta(format % args))


class Server(ThreadingHTTPServer):
    """`ThreadingHTTPServer` se stropem na počet souběžných spojení.

    Nad strop se spojení odmítne rovnou v přijímacím vlákně: odejde holá
    odpověď 503 a socket se zavře, žádné vlákno nevzniká. Odmítnutí se nepočítá
    do provozu — `Handler` se pro ně vůbec nezaloží — jen do čítače a do logu.
    """

    daemon_threads = True
    # Fronta jádra na přijetí spojení. `socketserver` má výchozích 5, což je tvrdší
    # strop než `MAX_SPOJENI` a při nárazu na něj narazí dřív: co se do fronty
    # nevejde, jádro odmítne ještě před `accept()` a klient dostane spojení odmítnuto
    # místo odpovědi 503.
    request_queue_size = 128

    def __init__(self, *args, max_spojeni=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.max_spojeni = MAX_SPOJENI if max_spojeni is None else max_spojeni
        self._volno = threading.BoundedSemaphore(self.max_spojeni)
        self.odmitnuta_spojeni = 0
        self._posledni_stiznost = 0.0

    def process_request(self, request, client_address):
        if not self._volno.acquire(blocking=False):
            self._odmitni(request)
            return
        try:
            super().process_request(request, client_address)
        except BaseException:
            # vlákno nevzniklo (typicky RuntimeError z `Thread.start`) — místo vrátit
            self._volno.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._volno.release()

    def _odmitni(self, request):
        self.odmitnuta_spojeni += 1
        ted = time.monotonic()
        if ted - self._posledni_stiznost > 60:
            self._posledni_stiznost = ted
            _LOGGER.warning("strop souběžných spojení %d vyčerpán, odmítnuto celkem %d",
                            self.max_spojeni, self.odmitnuta_spojeni)
        try:
            request.settimeout(5)
            request.sendall(b"HTTP/1.1 503 Service Unavailable\r\n"
                            b"Content-Length: 0\r\n"
                            b"Retry-After: 5\r\n"
                            b"Connection: close\r\n\r\n")
        except OSError:
            pass
        finally:
            self.shutdown_request(request)


def vytvor_server(host="0.0.0.0", port=VYCHOZI_PORT, data_dir=VYCHOZI_DATA, options=None,
                  predvyplnit=None):
    """Server s připravenými jádry. Nespouští smyčku — to dělá volající.

    Vrácené zdroje jsou ty z prostředí, tedy výchozí konfigurace. Uživatelé
    s vlastní adresou mají svoje a server o nich dopředu neví.
    """
    os.makedirs(data_dir, exist_ok=True)
    smazano = uklid_dat(data_dir)
    if smazano:
        _LOGGER.info("úklid: %d složek jader bez použití přes 30 dní", smazano)
    cztor.uklid(data_dir)   # ponytail: jen při startu; nasazuje se často, denní smyčku netřeba
    vychozi = options if options is not None else from_environ()
    enginy = Enginy(data_dir, vychozi, tmdb_key=os.environ.get("NOKTURNO_TMDB_KEY", "").strip())
    zdroje = sources_summary(enginy.pro())
    if predvyplnit is None:
        predvyplnit = os.environ.get("NOKTURNO_CONFIGURE_PREFILL", "").strip().lower() in ("1", "true", "ano", "yes")
    server = Server((host, port), Handler)
    # katalogy sdílí jednu cache pro všechny adresy; TMDB jen s klíčem instance (viz katalogy.py)
    provoz = Provoz.z_prostredi()
    tmdb_key = os.environ.get("NOKTURNO_TMDB_KEY", "").strip()
    # s klíčem instance (`tmdb_key` v nokturno.json) jdou vlastní katalogy přímo na TMDB, server je záloha
    dash = dash_lokalne(provoz, enginy.spolecne, TmdbApi(tmdb_key, cache=enginy.spolecne) if tmdb_key else None)
    katalogy = Katalogy(data_dir, os.environ.get("NOKTURNO_TMDB_KEY", ""), dash=dash)
    blokovane = {o.strip() for o in os.environ.get("NOKTURNO_BLOCKED_FINGERPRINTS", "").split(",") if o.strip()}
    server.router = Router(enginy, predvyplnit=predvyplnit, statistiky=Statistiky.z_prostredi(VERZE, data_dir=data_dir),
                           katalogy=katalogy, blokovane=blokovane, identita=Identita.z_prostredi(),
                           blokace=Blokace(soubor=os.path.join(data_dir, "odebrane_identity.txt"),
                                           adresy_soubor=os.path.join(data_dir, "zakazane_adresy.txt")))
    server.pady = Pady.z_prostredi(data_dir, VERZE)
    server.router.pady = server.pady
    if server.router.profily is not None:   # ověřené vlastní katalogy a koncerty (overovani.py)
        server.overovani = katalogy.overovani = Overovani(data_dir, enginy, dash, server.router.profily)
        server.overovani.start()
    if os.environ.get("NOKTURNO_SOUKROMA", "").strip().lower() in ("1", "true", "ano", "yes"):
        server.router.povolena = soukroma.Povolena(data_dir)
        _LOGGER.info("soukromá instance: povolená nastavení v %s", server.router.povolena.cesta)
    # NOKTURNO_PROFILY=0: starý režim bez profilů, adresa doplňku nese celé nastavení
    server.router.profily_vypnute = os.environ.get("NOKTURNO_PROFILY", "").strip().lower() in ("0", "false", "ne", "no")
    server.router.heslo = os.environ.get("NOKTURNO_HESLO", "")   # volitelné heslo k formuláři a profilům
    server.router.rezim_vychozi = server.router.rezim   # kam vrací tovární nastavení
    server.router.nastav_aplikaci(soukroma.nacti_aplikaci(data_dir))   # volby z /configure mají přednost
    server.router.spravce = spravce_mod.Spravce(data_dir)
    server.router.uzivatele = Uzivatele(data_dir, server.router.spravce.limit)
    server.router.spravce.ohlas()
    server.router.sdilena = os.environ.get("NOKTURNO_SDILENA", "").strip().lower() in ("1", "true", "ano", "yes")
    if server.router.sdilena:
        _LOGGER.info("sdílená instance: nastavení a ukládání profilů i z internetu")
    server.router.public_url = verejna_adresa(os.environ.get("NOKTURNO_PUBLIC_URL", ""))
    if server.router.public_url:
        _LOGGER.info("veřejná adresa doplňku: %s", server.router.public_url)
    server.pady.odesli()   # co zůstalo ve frontě z minula (server nebo síť tehdy neběžely)
    server.provoz = provoz
    server.router.zprava = server.provoz.zprava
    server.router.zobrazeni = server.provoz.zaznamenej_zobrazeni
    server.router.klik = server.provoz.zaznamenej_klik
    server.router.kliky = kliky_zprav.z_prostredi(data_dir)
    # nad stropem se nechají jen záznamy zpráv, které se ještě ukazují
    server.router.kliky.na_aktivni = lambda: {z[0] for z in server.provoz.zprava()}
    server.provoz.na_zakazane = server.router.blokace.nastav_zakazane
    server.provoz.start()  # bez NOKTURNO_TRAFFIC_TOKEN se vlákno nespustí a nic se neměří
    threading.Thread(target=_udrzba_smycka, args=(data_dir,), daemon=True).start()
    threading.Thread(target=_hlidac_zaseknutych, daemon=True).start()
    threading.Thread(target=_uklada_vyuziti, args=(server.router.vyuziti,), daemon=True).start()
    return server, zdroje


def spust_https(server, host, port, slozka):
    """Druhý posluchač s HTTPS (local-ip.co) nad tímtéž routerem — pro vlastní instanci
    v domácí síti, viz tls.py. Veřejná instance ho nepotřebuje, TLS dělá Cloudflare."""
    ctx = tls.kontext(slozka)
    if ctx is None:
        return None
    https = Server((host, port), Handler)
    # handshake až ve vlákně spojení pod `Handler.timeout`; v `accept()` by jedno tiché
    # spojení (TV usnula, spadla Wi-Fi) zablokovalo celý posluchač až do restartu
    https.socket = ctx.wrap_socket(https.socket, server_side=True, do_handshake_on_connect=False)
    https.schema = "https"
    for jmeno in ("router", "pady", "provoz"):
        setattr(https, jmeno, getattr(server, jmeno))
    server.router.https_port = port
    threading.Thread(target=https.serve_forever, daemon=True).start()
    _LOGGER.info("HTTPS pro Stremio v síti: https://<ip-s-pomlckami>.%s:%d", tls.DOMENA, port)
    threading.Thread(target=_zkontroluj_dns, daemon=True).start()
    return https


def _zkontroluj_dns():
    if not tls.dns_funguje():
        _LOGGER.warning(
            "DNS tohohle zařízení nepřeloží %s — nejspíš ho blokuje ochrana proti DNS rebinding "
            "(router, Pi-hole) nebo chybí internet. Stremio z jiných zařízení pak hlásí „Failed to fetch“. "
            "Povol doménu %s ve výjimkách ochrany.", f"127-0-0-1.{tls.DOMENA}", tls.DOMENA)


def verejna_adresa(text):
    """`https://nokturno.example.cz/` → `https://nokturno.example.cz`; nesmysl → "" (adresa z požadavku)."""
    text = (text or "").strip().rstrip("/")
    cast = urllib.parse.urlsplit(text)
    if cast.scheme not in ("http", "https") or not cast.hostname or cast.query or cast.fragment:
        return ""
    return text


def main(argv=None):
    ap = argparse.ArgumentParser(description="Nokturno pro Stremio")
    ap.add_argument("--host", default=os.environ.get("NOKTURNO_HOST", "0.0.0.0"))
    ap.add_argument("--port", type=int, default=int(os.environ.get("NOKTURNO_PORT", VYCHOZI_PORT)))
    ap.add_argument("--data", default=os.environ.get("NOKTURNO_DATA", VYCHOZI_DATA),
                    help="kam ukládat cache jádra (v kontejneru svazek, jinak se po restartu tahá znovu)")
    ap.add_argument("--debug", action="store_true")
    args = ap.parse_args(argv)
    keepalive.enable()   # spojení k API zdrojů se drží mezi dotazy (testy tuhle funkci nevolají)

    logging.basicConfig(level=logging.DEBUG if args.debug else logging.INFO,
                        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s")
    server, zdroje = vytvor_server(args.host, args.port, args.data)
    _LOGGER.info("Nokturno %s běží na http://%s:%d", VERZE, args.host, args.port)
    _LOGGER.info("zdroje výchozího nastavení: %s", ", ".join(zdroje) if zdroje else "žádné, viz README")
    _LOGGER.info("nastavení a adresa doplňku: http://<adresa tohohle stroje>:%d/configure", args.port)
    # `systemctl stop/restart` posílá SIGTERM a Python ho na výjimku nepřevádí — bez tohohle by
    # `finally` neproběhlo a fronta provozu i nedoručená hlášení o pádech se zahodily
    import signal
    https_port = int(os.environ.get("NOKTURNO_HTTPS_PORT") or 0)
    posluchace = [("HTTP", args.host, args.port, False)]
    if https_port and spust_https(server, args.host, https_port, os.path.join(args.data, "tls")) is not None:
        posluchace.append(("HTTPS", args.host, https_port, True))
    if os.environ.get("NOKTURNO_HLIDAC", "1").strip().lower() not in ("0", "false", "ne", "no"):
        # ukončit jen pod zavaděčem (ten nastaví NOKTURNO_UPDATE_URL; APK ho má prázdné, běží v jeho procesu)
        hlidac = HlidacPosluchacu(posluchace, pady=server.pady, ukoncit=bool(os.environ.get("NOKTURNO_UPDATE_URL")))
        threading.Thread(target=hlidac.bez, daemon=True, name="nokturno-hlidac").start()
    try:
        signal.signal(signal.SIGTERM, lambda *_: threading.Thread(target=server.shutdown, daemon=True).start())
    except ValueError:
        pass   # mimo hlavní vlákno (APK spouští doplněk z vlákna služby)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        _LOGGER.info("končím")
        server.provoz.stop()
        server.provoz.odesli()   # co se nastřádalo od poslední dávky
        server.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
